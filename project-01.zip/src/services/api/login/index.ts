import * as mock from "./mock";

export const postLogin = mock.postLogin;
