export const freeze = async () => {
  setTimeout(() => {}, 1000);
};
